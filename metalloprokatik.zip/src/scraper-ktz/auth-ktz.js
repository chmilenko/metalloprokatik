/**
 * auth-ktz.js
 *
 * Авторизация на КТЗ. В отличие от mc.ru (отдельная страница логина,
 * без кода подтверждения) — тут ДВА усложнения:
 *   1. Форма логина всплывает МОДАЛЬНО (кликом по "Личный кабинет" на
 *      главной), а не отдельной страницей.
 *   2. После ввода логина/пароля сайт запрашивает КОД ПОДТВЕРЖДЕНИЯ
 *      (2FA) — автоматически ввести его мы не можем (это код из
 *      SMS/почты, у нас нет программного доступа туда). Поэтому вместо
 *      попытки автоматизировать 2FA целиком — сохраняем сессию на диск
 *      ПОСЛЕ первого ручного входа, и переиспользуем её при следующих
 *      запусках. Код подтверждения вводится вручную только один раз
 *      (или изредка, когда сохранённая сессия истечёт).
 *
 * Логин/пароль — из .env: KTZ_LOGIN, KTZ_PASSWORD.
 */

const readline = require("readline");
const path = require("path");
const fs = require("fs");
const logger = require("../utils/logger");
const { getBrowser, setPage } = require("../scraper/browser");

const delay = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const HOME_URL = "https://ktzholding.com/";
const CART_URL = "https://ktzholding.com/cart";
const SESSION_PATH = path.join(__dirname, "../../downloads/ktz-session.json");

function ждиВводаВКонсоли(вопрос) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise((resolve) => {
    rl.question(вопрос, () => {
      rl.close();
      resolve();
    });
  });
}

/**
 * Возвращает готовую авторизованную страницу КТЗ. Порядок действий:
 *   1. Если есть сохранённая сессия на диске — пробуем её (открываем
 *      /cart, смотрим, не редиректнуло ли на главную — если нет, сессия
 *      ещё жива, дальше логиниться не нужно).
 *   2. Если сессии нет или она протухла — идём на полный вход, ждём
 *      РУЧНОГО ввода кода подтверждения (сайт запрашивает при первом
 *      входе — автоматически мы это не вводим), затем сохраняем
 *      получившуюся сессию на диск для следующих запусков.
 * @returns {Promise<import('playwright').Page>}
 */
// Вводит код подтверждения в форму — 6 (или сколько окажется) отдельных
// полей по одной цифре каждое. Ищем по подстроке класса "codeInput" (не
// по автогенерируемым id вида "_r_13_" — та же осторожность, что и
// везде в этом файле). Код передаётся строкой цифр, дефисы/пробелы
// внутри игнорируются ("123456" и "123-456" — одно и то же).
async function введиКодПодтверждения(page, code) {
  const цифры = String(code).replace(/[^0-9]/g, "").split("");

  const поля = await page.locator('[class*="codeInputWrapper"] input').all();

  if (поля.length === 0) {
    throw new Error("Не нашли поля ввода кода подтверждения на странице");
  }
  if (поля.length !== цифры.length) {
    logger.warn("КТЗ: число полей кода не совпадает с длиной кода", {
      полейНаСтранице: поля.length,
      цифрВКоде: цифры.length,
    });
  }

  for (let i = 0; i < Math.min(поля.length, цифры.length); i++) {
    await поля[i].click();
    await page.keyboard.type(цифры[i], { delay: 60 });
    await delay(100);
  }

  await delay(500);
  logger.info("КТЗ: код подтверждения введён");
}

async function authorizeKTZ() {
  const browser = await getBrowser();

  // ============================================================
  // 1. ПРОБУЕМ СОХРАНЁННУЮ СЕССИЮ
  // ============================================================

  if (fs.existsSync(SESSION_PATH)) {
    logger.info("КТЗ: пробуем сохранённую сессию", { путь: SESSION_PATH });
    const context = await browser.newContext({
      storageState: SESSION_PATH,
      userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
      acceptDownloads: true,
    });
    const page = await context.newPage();

    await page.goto(CART_URL);
    await page.waitForLoadState("domcontentloaded");
    await delay(1500);

    const попалиВКорзину = page.url().includes("/cart");
    if (попалиВКорзину) {
      logger.info("КТЗ: сохранённая сессия ещё жива, вход не требуется");
      setPage(page); // делаем страницу общей — её же вернёт обычный getPage()
      return page;
    }

    logger.info("КТЗ: сохранённая сессия истекла (редирект на главную), логинимся заново");
    await context.close();
  }

  // ============================================================
  // 2. ПОЛНЫЙ ВХОД — ЛОГИН/ПАРОЛЬ + РУЧНОЙ ВВОД КОДА ПОДТВЕРЖДЕНИЯ
  // ============================================================

  const login = process.env.KTZ_LOGIN;
  const password = process.env.KTZ_PASSWORD;
  if (!login || !password) {
    throw new Error("Не заданы KTZ_LOGIN/KTZ_PASSWORD в .env");
  }

  const context = await browser.newContext({
    userAgent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    acceptDownloads: true,
  });
  const page = await context.newPage();

  logger.info("КТЗ: переходим на главную для авторизации");
  await page.goto(HOME_URL);
  await page.waitForLoadState("domcontentloaded");
  await delay(2500);

  // --- Клик "Личный кабинет" ---
  const личныйКабинет = page.locator('img[alt="Личный кабинет"]').first();
  await личныйКабинет.waitFor({ state: "visible", timeout: 15000 });
  await личныйКабинет.locator("xpath=ancestor::a[1]").click();
  await delay(1200);

  // --- Поля логина/пароля ---
  await page.waitForSelector('input[name="login"]', { state: "visible", timeout: 5000 });
  await delay(300);

  await page.click('input[name="login"]');
  await page.keyboard.type(login, { delay: 40 });
  await delay(200);

  await page.click('input[name="password"]');
  await page.keyboard.type(password, { delay: 40 });
  await delay(200);

  const кнопкаВойти = page.locator('button[type="submit"]', { hasText: "Войти" }).first();
  await кнопкаВойти.waitFor({ state: "visible", timeout: 3000 });
  await кнопкаВойти.click();
  await delay(1500);

  // ============================================================
  // 3. КОД ПОДТВЕРЖДЕНИЯ — ВВОДИТСЯ ВРУЧНУЮ В ОКНЕ БРАУЗЕРА
  // ============================================================
  //
  // Браузер запущен НЕ headless (см. browser.js) — окно видно на
  // экране. Останавливаем скрипт и ждём, пока человек введёт код
  // подтверждения прямо в браузере и нажмёт там что нужно сам, а
  // затем подтвердит здесь, в консоли, что готово — продолжаем дальше.

  console.log("\n⏸  Сайт запросил код подтверждения (если запросил).");
  console.log("   Введите его В ОКНЕ БРАУЗЕРА вручную, дождитесь входа,");
  console.log("   затем вернитесь сюда и нажмите Enter, чтобы продолжить.\n");
  await ждиВводаВКонсоли("Нажмите Enter после входа в браузере... ");

  await delay(1000);

  // ============================================================
  // 4. ПРОВЕРКА УСПЕХА
  // ============================================================

  await page.goto(CART_URL);
  await page.waitForLoadState("domcontentloaded");
  await delay(1500);

  if (!page.url().includes("/cart")) {
    throw new Error(
      "После ручного ввода кода подтверждения всё равно не попали в корзину — вход не удался.",
    );
  }

  // ============================================================
  // 5. СОХРАНЯЕМ СЕССИЮ НА ДИСК — СЛЕДУЮЩИЕ ЗАПУСКИ СМОГУТ ЕЁ
  //    ПЕРЕИСПОЛЬЗОВАТЬ, БЕЗ ПОВТОРНОГО ВВОДА КОДА
  // ============================================================

  const outDir = path.dirname(SESSION_PATH);
  if (!fs.existsSync(outDir)) fs.mkdirSync(outDir, { recursive: true });
  await context.storageState({ path: SESSION_PATH });

  logger.info("КТЗ: авторизация прошла успешно, сессия сохранена", { путь: SESSION_PATH });

  setPage(page); // делаем страницу общей — её же вернёт обычный getPage()
  return page;
}

module.exports = { authorizeKTZ, введиКодПодтверждения };